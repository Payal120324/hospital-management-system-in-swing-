package ambulance.system;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class medicinegui extends javax.swing.JFrame {

    
    public medicinegui() {
        initComponents();
    }

   // MySQL database connection details
     final static String url = "jdbc:mysql://localhost:3306/pharma";
    final static String user = "root";
    final static String password = "root";
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtCost = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtMedId = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtMedName = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtCompany = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtExpiryDate = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtUnits = new javax.swing.JTextField();
        Showexistingstock = new javax.swing.JButton();
        addbutton = new javax.swing.JButton();
        deletemed = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtAreaStock = new javax.swing.JTextArea();
        checkalerts = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(0, 0, 102));
        jPanel2.setLayout(null);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 102));
        jLabel2.setText("Monitor Your Pharma Inventory !!");
        jLabel2.setOpaque(true);
        jPanel2.add(jLabel2);
        jLabel2.setBounds(40, 10, 370, 40);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\Payal\\Downloads\\med.PNG")); // NOI18N
        jPanel2.add(jLabel1);
        jLabel1.setBounds(0, -10, 190, 590);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Cost ");
        jLabel3.setFocusTraversalPolicyProvider(true);
        jPanel2.add(jLabel3);
        jLabel3.setBounds(200, 260, 60, 30);

        txtCost.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCostActionPerformed(evt);
            }
        });
        jPanel2.add(txtCost);
        txtCost.setBounds(250, 260, 190, 30);

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Medicine Id");
        jLabel4.setFocusTraversalPolicyProvider(true);
        jPanel2.add(jLabel4);
        jLabel4.setBounds(200, 60, 150, 30);

        txtMedId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMedIdActionPerformed(evt);
            }
        });
        jPanel2.add(txtMedId);
        txtMedId.setBounds(330, 60, 240, 30);

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Medicine Name");
        jLabel5.setFocusTraversalPolicyProvider(true);
        jPanel2.add(jLabel5);
        jLabel5.setBounds(200, 100, 170, 30);

        txtMedName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMedNameActionPerformed(evt);
            }
        });
        jPanel2.add(txtMedName);
        txtMedName.setBounds(370, 100, 240, 30);

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Company Name");
        jLabel6.setFocusTraversalPolicyProvider(true);
        jPanel2.add(jLabel6);
        jLabel6.setBounds(200, 140, 190, 30);

        txtCompany.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCompanyActionPerformed(evt);
            }
        });
        jPanel2.add(txtCompany);
        txtCompany.setBounds(380, 140, 240, 30);

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Expiry Date");
        jLabel7.setFocusTraversalPolicyProvider(true);
        jPanel2.add(jLabel7);
        jLabel7.setBounds(200, 180, 190, 30);

        txtExpiryDate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtExpiryDateActionPerformed(evt);
            }
        });
        jPanel2.add(txtExpiryDate);
        txtExpiryDate.setBounds(330, 180, 240, 30);

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Units(Quantity Of Medicine)");
        jLabel8.setFocusTraversalPolicyProvider(true);
        jPanel2.add(jLabel8);
        jLabel8.setBounds(200, 220, 300, 30);

        txtUnits.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUnitsActionPerformed(evt);
            }
        });
        jPanel2.add(txtUnits);
        txtUnits.setBounds(500, 220, 190, 30);

        Showexistingstock.setBackground(new java.awt.Color(255, 255, 0));
        Showexistingstock.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        Showexistingstock.setText("SHOW EXISTING STOCK");
        Showexistingstock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ShowexistingstockActionPerformed(evt);
            }
        });
        jPanel2.add(Showexistingstock);
        Showexistingstock.setBounds(600, 310, 250, 27);

        addbutton.setBackground(new java.awt.Color(255, 255, 0));
        addbutton.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        addbutton.setText("ADD MEDICINE");
        addbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addbuttonActionPerformed(evt);
            }
        });
        jPanel2.add(addbutton);
        addbutton.setBounds(200, 310, 180, 27);

        deletemed.setBackground(new java.awt.Color(255, 255, 0));
        deletemed.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        deletemed.setText("DELETE MEDICINE");
        deletemed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletemedActionPerformed(evt);
            }
        });
        jPanel2.add(deletemed);
        deletemed.setBounds(390, 310, 200, 27);

        txtAreaStock.setColumns(20);
        txtAreaStock.setRows(5);
        jScrollPane1.setViewportView(txtAreaStock);

        jPanel2.add(jScrollPane1);
        jScrollPane1.setBounds(230, 360, 590, 200);

        checkalerts.setBackground(new java.awt.Color(255, 255, 51));
        checkalerts.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        checkalerts.setText("CHECK ALERTS!!! ");
        checkalerts.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkalertsActionPerformed(evt);
            }
        });
        jPanel2.add(checkalerts);
        checkalerts.setBounds(630, 10, 190, 40);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 855, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 581, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
   
    private void txtCostActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCostActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCostActionPerformed

    private void txtMedIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMedIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMedIdActionPerformed

    private void txtMedNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMedNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMedNameActionPerformed

    private void txtCompanyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCompanyActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCompanyActionPerformed

    private void txtExpiryDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtExpiryDateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtExpiryDateActionPerformed

    private void txtUnitsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUnitsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUnitsActionPerformed
       
    
   private boolean validateFields() {
    String medicineID = txtMedId.getText().trim();
    String medicineName = txtMedName.getText().trim();
    String company = txtCompany.getText().trim();
    String expiryDate = txtExpiryDate.getText().trim();
    String unitsText = txtUnits.getText().trim();
    String costText = txtCost.getText().trim();

    // Check if Medicine ID is provided
    if (medicineID.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Medicine ID is required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
        return false;
    }
    
    // Check if Medicine Name is provided and contains only alphabets and spaces
    if (medicineName.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Medicine Name is required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
        return false;
    }
    if (!medicineName.matches("[a-zA-Z]+")) {
        JOptionPane.showMessageDialog(this, "Medicine Name must contain only alphabets .", "Validation Error", JOptionPane.ERROR_MESSAGE);
        return false;
    }
    
    // Check if Company Name is provided and contains only alphabets and spaces
    if (company.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Company Name is required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
        return false;
    }
    if (!company.matches("[a-zA-Z]+")) {
        JOptionPane.showMessageDialog(this, "Company Name must contain only alphabets.", "Validation Error", JOptionPane.ERROR_MESSAGE);
        return false;
    }
    
    // Check if Expiry Date is provided and is in the correct format
    if (expiryDate.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Expiry Date is required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
        return false;
    }
    if (!expiryDate.matches("\\d{4}-\\d{2}-\\d{2}")) {
        JOptionPane.showMessageDialog(this, "Expiry Date must be in the format YYYY-MM-DD.", "Validation Error", JOptionPane.ERROR_MESSAGE);
        return false;
    }

    // Check if Units are provided and are non-negative numbers
    if (unitsText.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Units are required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
        return false;
    }
    try {
        int units = Integer.parseInt(unitsText);
        if (units < 0) {
            JOptionPane.showMessageDialog(this, "Units cannot be negative.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Units must be a number.", "Validation Error", JOptionPane.ERROR_MESSAGE);
        return false;
    }

    // Check if Cost is provided and is a non-negative number
    if (costText.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Cost is required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
        return false;
    }
    try {
        double cost = Double.parseDouble(costText);
        if (cost < 0) {
            JOptionPane.showMessageDialog(this, "Cost cannot be negative.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Cost must be a number.", "Validation Error", JOptionPane.ERROR_MESSAGE);
        return false;
    }

    return true;
}


    private void addbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addbuttonActionPerformed
        if (!validateFields()) {
        return; // Stop further processing if validation fails
    }
    
    // Extract input values
    String id = txtMedId.getText().trim();
    String name = txtMedName.getText().trim();
    String company = txtCompany.getText().trim();
    String expiryDate = txtExpiryDate.getText().trim();
    int units = Integer.parseInt(txtUnits.getText().trim());
    double cost = Double.parseDouble(txtCost.getText().trim());

    // Database insertion logic
    String sql = "INSERT INTO medicines (Medicine_id, Medicine_name, Company_name, Expiry_date, Units, Cost) VALUES (?, ?, ?, ?, ?, ?)";

    try (Connection conn = DriverManager.getConnection(url, user, password);
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        // Set parameters
        pstmt.setString(1, id);
        pstmt.setString(2, name);
        pstmt.setString(3, company);
        pstmt.setString(4, expiryDate);
        pstmt.setInt(5, units);
        pstmt.setDouble(6, cost);
        
        // Execute update
        pstmt.executeUpdate();
        
        // Inform user of success
        JOptionPane.showMessageDialog(this, "Record Added Successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
    } catch (SQLException e) {
        // Handle SQL exceptions
        JOptionPane.showMessageDialog(this, "An error occurred while adding the record: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } catch (NumberFormatException e) {
        // Handle number format exceptions
        JOptionPane.showMessageDialog(this, "Invalid number format: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
      }
    }//GEN-LAST:event_addbuttonActionPerformed

    private void deletemedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletemedActionPerformed
          String id = txtMedId.getText();

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            String sql = "DELETE FROM medicines WHERE Medicine_id  = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, id);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Record Deleted Successfully");
            } else {
                JOptionPane.showMessageDialog(this, "Record Not Found");
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
      
    }//GEN-LAST:event_deletemedActionPerformed
     
    private void ShowexistingstockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ShowexistingstockActionPerformed
         try (Connection conn = DriverManager.getConnection(url, user, password)) {
            String sql = "SELECT * FROM medicines";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            StringBuilder sb = new StringBuilder();

            while (rs.next()) {
                sb.append("ID: ").append(rs.getString("Medicine_id"))
                  .append(", Name: ").append(rs.getString("Medicine_name"))
                  .append(", Company: ").append(rs.getString("Company_name"))
                  .append(", Expiry: ").append(rs.getString("Expiry_date"))
                  .append(", Units: ").append(rs.getString("Units"))
                  .append(", Cost: ").append(rs.getString("Cost"))
                  .append("\n");
            }

            txtAreaStock.setText(sb.toString());
        } catch (SQLException e) {
            e.printStackTrace();
        }   
    }//GEN-LAST:event_ShowexistingstockActionPerformed

    private void checkalertsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkalertsActionPerformed
             try (Connection conn = DriverManager.getConnection(url, user, password)) {
        // Query to check for expiring medicines or those with low stock
        String sql = "SELECT Medicine_name, Expiry_date, Units FROM medicines " +
                     "WHERE Expiry_date <= CURDATE() + INTERVAL 10 DAY " +
                     "OR Units <= 5";
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql);
        StringBuilder sb = new StringBuilder();

        while (rs.next()) {
            sb.append("Medicine: ").append(rs.getString("Medicine_name"))
              .append(", Expiry: ").append(rs.getString("Expiry_date"))
              .append(", Units: ").append(rs.getString("Units"))
              .append("\n");
        }

        if (sb.length() == 0) {
            sb.append("No alerts.");
        }

        JOptionPane.showMessageDialog(this, sb.toString());
    } catch (SQLException e) {
        e.printStackTrace();
    }        
    }//GEN-LAST:event_checkalertsActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(medicinegui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(medicinegui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(medicinegui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(medicinegui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new medicinegui().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Showexistingstock;
    private javax.swing.JButton addbutton;
    private javax.swing.JButton checkalerts;
    private javax.swing.JButton deletemed;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea txtAreaStock;
    private javax.swing.JTextField txtCompany;
    private javax.swing.JTextField txtCost;
    private javax.swing.JTextField txtExpiryDate;
    private javax.swing.JTextField txtMedId;
    private javax.swing.JTextField txtMedName;
    private javax.swing.JTextField txtUnits;
    // End of variables declaration//GEN-END:variables
}
